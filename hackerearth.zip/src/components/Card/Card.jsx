import "./Card.scss";

function Card({ Image, name, id }) {
  return (
    <div className="card">
      <img src={Image} alt="" />
      <h1>{name}</h1>
      <p>{id}</p>
    </div>
  );
}

export default Card;
